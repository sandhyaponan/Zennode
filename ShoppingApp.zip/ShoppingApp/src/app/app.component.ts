import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent {
  constructor(){

  }
  setValue:boolean=false;
  payableValue:number=0;
  title = 'ShoppingApp';
  products =[{name:'product1',price:20,count:0 },{name:'product2',price:40,count:0},{name:'product3',price:50,count:0}] ;
  giftWrap:boolean=false;
  shipping:number=0;
  list= {
    "products": [
        {
            "id": 1,
            "name": "Product A",
            "price": 20,
            "qty": 0,
            "total": 0
        },
        {
            "id": 2,
            "name": "Product B",
            "price": 40,
            "qty": 0,
            "total": 0
        },
        {
          "id": 3,
          "name": "Product B",
          "price": 50,
          "qty": 0,
          "total": 0
      }
    ],
    "subtotal": 0,
    "discountAmount": 0,
    "giftwrap": false,
    "giftwrapCharge": 0,
    "shippingfee": 0,
    "grandTotal": 0,
    "totalItems":0,
    "initialWrapCheck":false,
    "offers":[]
}
 totalQty:number = 0;
 wraps:number=0;
 grandTotal = 0;
 discountArray = [];
  ngOnInit(){

  }
  sendInput(event:any,pro1:any){
    this.list.products.map((val)=>{
      if(val.id===pro1.id){
         val.qty = parseInt(event.target.value);
         val.total = parseInt(event.target.value)*val.price;
      }
    });
    console.log(this.list);
    this.list.totalItems = this.list.products.reduce((acc,value)=>{
      
      return acc+value.qty;
    },0);
    this.list.grandTotal = this.list.products.reduce((acc,value)=>{
      return acc+(value.price*value.qty);
    },0);
    this.list.shippingfee = Math.ceil(this.list.totalItems/10); 
     this.list.products.map(value=>value.total==value.qty*value.price);   
  }
  wrap(event?:any){
    if(event.target.checked){
      return true;
    }
    else{
      return false;
    }
    
  }
  showOffer(){
    this.setValue=true;
    let payable=[];
    if(this.list.grandTotal>200){
      let total = this.list.grandTotal*10/100;
       // @ts-ignore
      this.list.offers.push(0);
      payable.push(total);
    }
    this.list.products.forEach((value,index)=>{
      if(value.qty>10){
         // @ts-ignore
        this.list.offers.push(1);
        let total=Number(this.list.products[index].price* this.list.products[index].qty);
      }
      else{
        // @ts-ignore
        this.list.offers.push(4);
        payable.push(this.list.grandTotal)
      }
    });
    this.list.products.forEach(value=>{
      if(value.qty>20){
        // @ts-ignore
        this.list.offers.push(2);
        payable.push(this.grandTotal*10/100);
      }
    });
    this.list.products.forEach(value=>{
      if(value.qty>15 && this.list.totalItems>15 ){
        // @ts-ignore
        this.list.offers.push(3);
        let temp = this.grandTotal-(value.qty*value.price)+(15*value.price)+((value.qty-15)*value.price*50/100)
        payable.push(temp);
      }
    });
    this.payableValue = Math.min.apply(Math,payable);
    
  }
}
